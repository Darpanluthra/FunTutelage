package com.example.hariomloginregister;

public class MemberC {

    private String dat;

    public MemberC() {
    }

    public String getDat() {
        return dat;
    }

    public void setDat(String dat) {
        this.dat = dat;
    }
}
