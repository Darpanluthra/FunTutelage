package com.example.hariomloginregister;

public class mAuth {

    String uid;
    String email;
    String pswd;
}
