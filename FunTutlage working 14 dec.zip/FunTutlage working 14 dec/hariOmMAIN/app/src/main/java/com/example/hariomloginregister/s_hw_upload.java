package com.example.hariomloginregister;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;
import java.util.Map;

public class s_hw_upload extends AppCompatActivity {
    Button ch,up;
    ImageView img;
    StorageReference mStorageRef;
    private StorageTask uploadTask;
    public Uri imguri, dnldUrl;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s_hw_upload);


        mStorageRef= FirebaseStorage.getInstance().getReference("Homework");
        ch=(Button)findViewById(R.id.btnchoose);
        up=(Button)findViewById(R.id.btnupload);
        img=(ImageView) findViewById(R.id.imgview);

        ch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                filechooser();

            }
        });

        up.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                if(uploadTask!=null && uploadTask.isInProgress())
                {
                    Toast.makeText(s_hw_upload.this, "Upload in progress", Toast.LENGTH_SHORT).show();
                }
                fileUploader();

            }
        });

    }

    private void openPage2() {
        Intent intent=new Intent(this, testlogin.class);
        startActivity(intent);
    }

    private String getExtention(Uri uri){
        ContentResolver cr=getContentResolver();
        MimeTypeMap mimeTypeMap =MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(cr.getType(uri));

    }

    private void fileUploader()
    {
        FirebaseAuth mAuth=FirebaseAuth.getInstance();
        String uid=mAuth.getCurrentUser().getUid();
        final StorageReference Ref=mStorageRef.child(uid+"."+getExtention(imguri));
        final FirebaseFirestore db = FirebaseFirestore.getInstance();



// earlier it was just    ->      Ref.putFile(imguri)
        uploadTask=Ref.putFile(imguri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        // Get a URL to the uploaded content
//                         Uri dnldUrl = taskSnapshot.getDownloadUrl();
                        Ref.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                String downloadUrl = uri.toString();

                                Map<String, String> user = new HashMap<>();

                                user.put("link", downloadUrl);

                                db.collection("s_hw_submition").document("imgLink").set(user)
                                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                                            @Override
                                            public void onSuccess(Void aVoid) {
                                                Log.d("onSuccess", "data stored successfully");

                                                //    startActivity(new Intent(t_hw_post.this,IstPage.class));

                                            }
                                        }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Log.d("onFailure", "Exception"+e);
                                        Toast.makeText(getApplicationContext(), "Please re-enter details", Toast.LENGTH_SHORT).show();

                                    }
                                });

                            }
                        });

                        Toast.makeText(s_hw_upload.this, "Image Uploaded SuccessFully", Toast.LENGTH_SHORT).show();

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception exception) {
                        Toast.makeText(s_hw_upload.this, "Not Uploaded ", Toast.LENGTH_SHORT).show();

                    }
                });
    }

    private void filechooser(){

        Intent intent=new Intent();
        intent.setType("image/");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode==1 && resultCode==RESULT_OK && data!=null && data.getData()!=null){

            imguri=data.getData();
            img.setImageURI(imguri);
        }
    }
}
