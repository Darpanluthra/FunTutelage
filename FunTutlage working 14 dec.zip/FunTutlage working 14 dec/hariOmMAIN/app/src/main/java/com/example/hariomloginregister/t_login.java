package com.example.hariomloginregister;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class t_login extends AppCompatActivity {


    EditText remail, rpswd;
    Button loginBtn;
    TextView tvSingnUp;

    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t_login);

        progressDialog = new ProgressDialog(this);
   final     FirebaseAuth mFirebaseAuth;

        mFirebaseAuth = FirebaseAuth.getInstance();
        remail = findViewById(R.id.tfemail);
        rpswd = findViewById(R.id.tfpswd);
        loginBtn = findViewById(R.id.loginBtn);
        tvSingnUp = findViewById(R.id.tvSignUp);


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String vemail = remail.getText().toString();
                String vpswd = rpswd.getText().toString();

                if (vemail.isEmpty()) {
                    remail.setError("Please Enter Email");
                    remail.requestFocus();
                } else if (vpswd.isEmpty()) {
                    rpswd.setError("Please Enter Password");
                    rpswd.requestFocus();
                } else if (vemail.isEmpty() && vpswd.isEmpty()) {
                    remail.setError("Please Enter Email");
                    rpswd.setError("Please enter password");
                    Toast.makeText(t_login.this, "Please provide mandatory information", Toast.LENGTH_SHORT).show();
                } else if (!(vemail.isEmpty() && vpswd.isEmpty())) {

                    mFirebaseAuth.signInWithEmailAndPassword(vemail, vpswd).addOnCompleteListener(t_login.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                //  startActivity(new Intent(s_login.this, s_hw_retrieve.class));

                                FirebaseUser user = mFirebaseAuth.getCurrentUser();
                               // updateUI(user);

                                Intent myIntent = new Intent(t_login.this, t_hw_post.class);
                                myIntent.putExtra("name", "FirstKeyValue");
                                myIntent.putExtra("class", "SecondKeyValue");
                                startActivity(myIntent);
                                Toast.makeText(t_login.this, "Login Successful", Toast.LENGTH_SHORT).show();

                            } else {
                                Toast.makeText(t_login.this, "Login Error , please s_login againn", Toast.LENGTH_SHORT).show();

                            }

                        }
                    });

                }

            }
        });


        tvSingnUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(t_login.this, t_signUp.class));
            }
        });


    }

}